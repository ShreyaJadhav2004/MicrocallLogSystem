<?php
$hostname='localhost';
$username='root';
$password='';
$databasename='db_mcs_call_log';

$mysqli=mysqli_connect($hostname,$username,$password,$databasename);

?>